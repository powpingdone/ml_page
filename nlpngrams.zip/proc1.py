from nltk import word_tokenize
from nltk.util import ngrams
from copy import deepcopy as copy
from pickle import dump
from sys import argv, exit


def readin(fname: str) -> (dict, dict):
    with open(fname) as inp:
        corpus = inp.read()
    corpus.replace('\n', '')
    uni = word_tokenize(corpus)
    big = list(ngrams(copy(uni), 2))
    uni_d = {t: uni.count(t) for t in set(uni)}
    # did not intend for this name
    # oops
    big_d = {t: big.count(t) for t in set(big)}
    return uni_d, big_d


def main():
    if len(argv) != 4:
        print(
            f"usage: {argv[0]} <training data> <training data> <training data>")
        exit(1)
    for fname in argv[1:]:
        un, bi = readin(fname)
        typ = fname.split('.')[-1]
        with open(f"{typ}_un.pkl", "wb") as outp:
            dump(un, outp)
        with open(f"{typ}_bi.pkl", "wb") as outp:
            dump(bi, outp)


if __name__ == "__main__":
    main()
