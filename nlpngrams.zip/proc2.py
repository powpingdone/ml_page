from sys import argv, exit
from nltk.util import ngrams
from nltk import word_tokenize
from pickle import load
from copy import deepcopy as copy
from glob import glob


def compute_prob(inp: str, uni: dict, big: dict, full_size: int) -> float:
    big_tokens = list(ngrams(copy(word_tokenize(inp)), 2))
    prob = 1
    for bigram in big_tokens:
        prob *= (big[bigram] if bigram in big else 1) / \
            (uni[bigram[0]] if bigram[0] in uni else full_size)
    return prob


def main():
    if len(argv) != 4:
        print(f"usage: {argv[0]} <testfile> <outfile> <check_accuracy>")
        exit(1)
    # load pickles
    langs = list(set([fname.split('_')[0] for fname in glob("*.pkl")]))
    unis = {}
    bigs = {}
    for lang in langs:
        for typ in ['un', 'bi']:
            with open(f"{lang}_{typ}.pkl", "rb") as pkl:
                loaded = load(pkl)
                if typ == 'un':
                    unis[lang] = loaded
                else:
                    bigs[lang] = loaded
    # get total vocab
    uni_len = sum([len(x) for x in unis.items()])
    correct = 0
    full_amt = 0
    with open(argv[1]) as testfile, open(argv[2], "w") as outfile, open(argv[3]) as check_accuracy:
        for ((line, content), actual) in zip(enumerate(testfile, start=1), check_accuracy):
            actual = actual.strip().split()[-1]
            content = content.strip()
            # i don't get why a smaller probability works better
            # but hey, anything for that accuracy amirite
            curr_guess = ("Unknown", 1.0)
            for lang in langs:
                guess = compute_prob(
                    content, unis[lang], bigs[lang], uni_len)
                if curr_guess[1] > guess:
                    curr_guess = (lang, guess)
            outfile.write(f"{line} {curr_guess[0]}\n")
            if actual != curr_guess[0]:
                print(f"L{line}:\tguessed {curr_guess[0]}, but was {actual}")
            else:
                correct += 1
            full_amt += 1
    print(f"Accuracy: {correct/full_amt}")


if __name__ == "__main__":
    main()
