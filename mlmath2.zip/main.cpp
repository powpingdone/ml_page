#include "csv.hpp"
#include "logreg.hpp"
#include "nb.hpp"

#include <chrono>
#include <iostream>

int main() {
    DataSet ds(std::ifstream("titanic_project.csv"));
    LogReg  lr;
    auto    pt = std::chrono::system_clock::now();
    lr.train(ds.ds_sex, ds.ds_survived, 500000, 0.001);
    auto pt2 = std::chrono::system_clock::now();
    lr.test(ds.ds_sex, ds.ds_survived);
    std::cout << "Time taken: "
              << std::chrono::duration_cast<std::chrono::milliseconds>(pt2 - pt).count() << " ms"
              << std::endl;
    NB nb;
    pt = std::chrono::system_clock::now();
    nb.train(ds);
    pt2 = std::chrono::system_clock::now();
    nb.test(ds);
    std::cout << "Time taken: "
              << std::chrono::duration_cast<std::chrono::milliseconds>(pt2 - pt).count() << " ms"
              << std::endl;
}
