#include "logreg.hpp"
#include <cmath>
#include <iostream>
#include <vector>

double sigmoid(double x) {
    return 1 / (1 + std::exp(-x));
}

#define SPLIT 800

void LogReg::train(std::vector<bool> X, std::vector<bool> Y, uint64_t iters, double lr) {
    for(int iter = 0; iter < iters; iter++) {
        // get errors
        double total_error[2] = {0.0, 0.0};
        for(int i = 0; i < SPLIT; i++) {
            double sex = (double)X.at(i);
            double calc_prob = sigmoid(this->weights[0] + this->weights[1] * sex);
            double error = Y.at(i) - calc_prob;
            total_error[0] += lr * error;
            total_error[1] += lr * (sex * error);
        }
        // update weights
        this->weights[0] += total_error[0];
        this->weights[1] += total_error[1];
    }
}

void LogReg::test(std::vector<bool> X, std::vector<bool> Y) {
    int t_p = 0, t_n = 0, f_n = 0, f_p = 0;
    for(int i = SPLIT; i < X.size(); i++) {
        // hehe
        int    real = (int)Y.at(i);
        double sex = (double)X.at(i);
        double pred = sigmoid(this->weights[0] + this->weights[1] * sex);
        int    prob = (int)round(exp(pred) / (1 + exp(pred)));
        // update stats
        if(real == prob) {
            if(prob == 1)
                t_p += 1;
            else
                t_n += 1;
        } else {
            if(prob == 1)
                f_p += 1;
            else
                f_n += 1;
        }
    }
    std::cout << "LogReg:" << std::endl
              << "Coeff: P_0:" << weights[0] << " P_1:" << weights[1] << std::endl
              << "Accuracy: " << (double)(t_p + t_n) / (double)(t_p + t_n + f_n + f_p) << std::endl
              << "Sensitivity: " << (double)(t_p) / (double)(t_p + f_n) << std::endl
              << "Specificity: " << (double)(t_n) / (double)(t_n + f_p) << std::endl;
}
