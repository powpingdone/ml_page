#ifndef LOGREG_HPP
#define LOGREG_HPP

#include <cstdint>
#include <vector>
class LogReg {
    public:
    LogReg() { }
    void train(std::vector<bool>, std::vector<bool>, uint64_t, double);
    void test(std::vector<bool>, std::vector<bool>);

    private:
    double weights[2] = {0.0, 0.0};
};

#endif
