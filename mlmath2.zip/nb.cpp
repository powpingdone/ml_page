#include "nb.hpp"
#include "csv.hpp"
#include <cmath>
#include <cstdint>
#include <iostream>

#define SPLIT 800

void NB::train(DataSet& ds) {
    // apriori
    int surv = 0;
    for(int i = 0; i < SPLIT; i++) {
        surv += ds.ds_survived.at(i) == 1 ? 1 : 0;
    }
    apriori[0] = (double)(SPLIT - surv) / SPLIT;
    apriori[1] = (double)(surv) / SPLIT;

    // lh_class
    for(int surv_i = 0; surv_i < 2; surv_i++) {
        for(int class_i = 0; class_i < 3; class_i++) {
            // count the amount that exist
            // this can defo be optimized, but i'm out of time
            // -O2 save me!
            int fulfill = 0;
            for(int i = 0; i < SPLIT; i++) {
                fulfill += (uint8_t)(ds.ds_survived.at(i)) == surv_i
                        && (ds.ds_pclass.at(i) - 1) == class_i ?
                    1 :
                    0;
            }
            lh_class[surv_i][class_i]
                = (double)fulfill / (double)(surv_i == 0 ? (SPLIT - surv) : surv);
        }
    }

    // lh_sex
    // repeat above
    for(int surv_i = 0; surv_i < 2; surv_i++) {
        for(int sex_i = 0; sex_i < 2; sex_i++) {
            int fulfill = 0;
            for(int i = 0; i < SPLIT; i++) {
                fulfill += (uint8_t)(ds.ds_survived.at(i)) == surv_i
                        && (uint8_t)(ds.ds_sex.at(i)) == sex_i ?
                    1 :
                    0;
            }
            lh_sex[surv_i][sex_i] = (double)fulfill / (double)(surv_i == 0 ? (SPLIT - surv) : surv);
        }
    }

    // age_mean
    uint64_t accum[2] = {0, 0};
    for(int i = 0; i < SPLIT; i++) {
        accum[(int)ds.ds_survived.at(i)] += ds.ds_age.at(i);
    }
    age_mean[0] = (double)accum[0] / (SPLIT - surv);
    age_mean[1] = (double)accum[1] / surv;

    // age_var
    double accum_var[2] = {0, 0};
    for(int i = 0; i < SPLIT; i++) {
        accum_var[(int)ds.ds_survived.at(i)]
            += pow(ds.ds_age.at(i) - age_mean[(int)ds.ds_survived.at(i)], 2);
    }
    age_var[0] = sqrt(accum_var[0] / (SPLIT - surv - 1));
    age_var[1] = sqrt(accum_var[1] / (surv - 1));
}

double quant_prob(double x, double mean, double var) {
    return (1 / sqrt(2 * M_PI * var)) * exp(-pow(x - mean, 2) / (2 * var));
}

// yes i shamelessly copied LogReg::test
void NB::test(DataSet& ds) {
    int t_p = 0, t_n = 0, f_n = 0, f_p = 0;
    for(int i = SPLIT; i < ds.ds_survived.size(); i++) {
        // hehe, again
        int    real = (int)ds.ds_survived.at(i);
        int    sex = (int)ds.ds_sex.at(i);
        int    pclass = (int)ds.ds_pclass.at(i) - 1;
        int    age = (int)ds.ds_age.at(i);
        double pred[2] = {0.0, 0.0};
        double denom = lh_class[0][pclass] * lh_sex[0][sex]
            * quant_prob(age, age_mean[0], age_var[0]) * apriori[0] * lh_class[1][pclass]
            * lh_sex[1][sex] * quant_prob(age, age_mean[1], age_var[1]) * apriori[1];
        double dead = (lh_class[0][pclass] * lh_sex[0][sex]
                          * quant_prob(age, age_mean[0], age_var[0]) * apriori[0])
            / denom;
        double alive = (lh_class[1][pclass] * lh_sex[1][sex]
                           * quant_prob(age, age_mean[1], age_var[1]) * apriori[1])
            / denom;
        int prob = alive > dead ? 1 : 0;

        // update stats
        if(real == prob) {
            if(prob == 1)
                t_p += 1;
            else
                t_n += 1;
        } else {
            if(prob == 1)
                f_p += 1;
            else
                f_n += 1;
        }
    }
    std::cout << "Naive Bayes:" << std::endl
              << "Coeff:" << std::endl
              << "class:" << std::endl
              << "\t" << lh_class[0][0] << "\t" << lh_class[1][0] << std::endl
              << "\t" << lh_class[0][1] << "\t" << lh_class[1][1] << std::endl
              << "\t" << lh_class[0][2] << "\t" << lh_class[1][2] << std::endl
              << "sex:" << std::endl
              << "\t" << lh_sex[0][0] << "\t" << lh_sex[1][0] << std::endl
              << "\t" << lh_sex[0][1] << "\t" << lh_sex[1][1] << std::endl
              << "age_mean: mu_0:" << age_mean[0] << " mu_1:" << age_mean[1] << std::endl
              << "age_var: S_0:" << age_var[0] << " S_1:" << age_var[1] << std::endl
              << "apriori: Surv_0:" << apriori[0] << " Surv_1:" << apriori[1] << std::endl
              << "Accuracy: " << (double)(t_p + t_n) / (double)(t_p + t_n + f_n + f_p) << std::endl
              << "Sensitivity: " << (double)(t_p) / (double)(t_p + f_n) << std::endl
              << "Specificity: " << (double)(t_n) / (double)(t_n + f_p) << std::endl;
}
