#ifndef CSV_HPP
#define CSV_HPP
#include <fstream>
#include <vector>

class DataSet {
    public:
    DataSet(std::ifstream);

    std::vector<double> ds_pclass, ds_age;
    std::vector<bool>   ds_survived, ds_sex;
};

#endif
