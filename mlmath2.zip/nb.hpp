#ifndef NB_HPP
#define NB_HPP

#include "csv.hpp"
#include <cstdint>
class NB {
    public:
    NB() { }
    void train(DataSet&);
    void test(DataSet&);

    private:
    double apriori[2] = {0.0, 0.0};
    double lh_class[2][3] = {{0.0, 0.0, 0.0}, {0.0, 0.0, 0.0}};
    double lh_sex[2][2] = {{0.0, 0.0}, {0.0, 0.0}};
    double age_mean[2] = {0.0, 0.0}, age_var[2] = {0.0, 0.0};
};

#endif
