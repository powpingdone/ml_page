#include "csv.hpp"
#include <sstream>
#include <string>

DataSet::DataSet(std::ifstream inp) {
    std::string buf("");
    std::getline(inp, buf, '\n');
    while(std::getline(inp, buf, '\n')) {
        if(buf == "") {
            // skip blank lines
            continue;
        }
        // copy into strstream and parse that
        std::stringstream buf2(buf);
        std::string       pclass(""), survive(""), sex(""), age("");
        // skip first column
        std::getline(buf2, pclass, ',');
        std::getline(buf2, pclass, ',');
        std::getline(buf2, survive, ',');
        std::getline(buf2, sex, ',');
        std::getline(buf2, age, ',');
        // then shove into self
        this->ds_pclass.push_back(std::stod(pclass));
        this->ds_survived.push_back((bool)std::stod(survive));
        this->ds_sex.push_back((bool)std::stod(sex));
        this->ds_age.push_back(std::stod(age));
    }
}
