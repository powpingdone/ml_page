#include "csv.hpp"
#include "math.hpp"
#include <iostream>

int main() {
    DataSet ds(std::ifstream("Boston.csv"));
    std::cout << "Rm:" << std::endl
              << "\tSum:\t" << sum(ds.ds_rm) << std::endl
              << "\tMean:\t" << mean(ds.ds_rm) << std::endl
              << "\tMedian:\t" << median(ds.ds_rm) << std::endl
              << "\tRange:\t" << range(ds.ds_rm) << std::endl;
    std::cout << "Medv:" << std::endl
              << "\tSum:\t" << sum(ds.ds_medv) << std::endl
              << "\tMean:\t" << mean(ds.ds_medv) << std::endl
              << "\tMedian:\t" << median(ds.ds_medv) << std::endl
              << "\tRange:\t" << range(ds.ds_medv) << std::endl;
    std::cout << "Covariance:" << covariance(ds.ds_rm, ds.ds_medv) << std::endl;
    std::cout << "Correlation:" << correlation(ds.ds_rm, ds.ds_medv) << std::endl;
}
