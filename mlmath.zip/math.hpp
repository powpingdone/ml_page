#ifndef MATH_HPP
#define MATH_HPP
#include <vector>

double sum(std::vector<double>&);
double mean(std::vector<double>&);
double median(std::vector<double>&);
double range(std::vector<double>&);
double covariance(std::vector<double>&, std::vector<double>&);
double correlation(std::vector<double>&, std::vector<double>&);

#endif
