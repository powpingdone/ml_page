#ifndef CSV_HPP
#define CSV_HPP
#include <fstream>
#include <vector>

class DataSet {
    public:
    DataSet(std::ifstream);

    std::vector<double> ds_medv, ds_rm;
};

#endif
