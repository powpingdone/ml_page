#include "csv.hpp"
#include <sstream>
#include <string>

DataSet::DataSet(std::ifstream inp) {
    std::string buf("");
    std::getline(inp, buf, '\n');
    while(std::getline(inp, buf, '\n')) {
        if(buf == "") {
            // skip blank lines
            continue;
        }
        // copy into strstream and parse that
        std::stringstream buf2(buf);
        std::string       rm(""), medv("");
        std::getline(buf2, rm, ',');
        std::getline(buf2, medv, ',');
        // then shove into self
        this->ds_rm.push_back(std::stod(rm));
        this->ds_medv.push_back(std::stod(medv));
    }
}
