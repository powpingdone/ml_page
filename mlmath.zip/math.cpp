#include "math.hpp"
#include <algorithm>
#include <cmath>
#include <limits>

double sum(std::vector<double>& vec) {
    double sum = 0;
    for(double x: vec) {
        sum += x;
    }
    return sum;
}

double mean(std::vector<double>& vec) {
    return sum(vec) / vec.size();
}

// why does this function exist?
// because you can't define std::vector<double&> because it's internally a pointer
// which makes the reference potentially invalid, so cpp doesnt allow it
// thanks cpp
std::vector<double> sorted_copy(std::vector<double>& vec) {
    std::vector<double> silent_copy(vec);
    std::sort(silent_copy.begin(), silent_copy.end());
    return silent_copy;
}

double median(std::vector<double>& vec) {
    return sorted_copy(vec).at((vec.size() - 1) / 2);
}

double range(std::vector<double>& vec) {
    double min = std::numeric_limits<double>::max(), max = std::numeric_limits<double>::min();
    for(double& x: vec) {
        if(min > x) {
            min = x;
        }
        if(max < x) {
            max = x;
        }
    }
    return max - min;
}

double covariance(std::vector<double>& x, std::vector<double>& y) {
    double              mx = mean(x), my = mean(y);
    std::vector<double> mults;
    for(ssize_t i = 0; i < x.size() && i < y.size(); i++) {
        mults.push_back((x[i] - mx) * (y[i] - my));
    }
    return sum(mults) / (mults.size() - 1);
}

double correlation(std::vector<double>& x, std::vector<double>& y) {
    return covariance(x, y) / (sqrt(covariance(x, x)) * sqrt(covariance(y, y)));
}
