from bs4 import BeautifulSoup as BS
from urllib.request import urlopen
from urllib.parse import urlparse, ParseResult
from nltk.tokenize import word_tokenize, sent_tokenize
from nltk.corpus import stopwords, words
from copy import deepcopy as copy
import re
from math import log
from pickle import dump, load
from os.path import exists
from sys import stdout
from glob import iglob as glob

URL = "https://en.wikipedia.org/wiki/Rust_(programming_language)"
ENG_CORPUS = set(words.words())


def fix_urls(orig_url: ParseResult, urls: [str]) -> [str]:
    for i in range(len(urls)):
        curl = urls[i]
        # //url.com/a/b
        # hope to GOD that this url is "normal"
        if len(curl) > 2 and curl[:2] == "//":
            curl = f"https:{curl}"
        # /a/b
        elif len(curl) > 1 and curl[0] == "/":
            curl = f"{orig_url.scheme}://{orig_url.netloc}{curl}"
        urls[i] = curl
    return urls


def similar_text_filter(inp: str) -> [str]:
    regex = re.compile(r"\w*")
    sw = stopwords.words("english")
    return [
        word.strip()
        for word in word_tokenize(inp.lower())
        if re.fullmatch(regex, word)
        and word not in sw
        and word.strip() != ""
        and word in ENG_CORPUS
    ]


def similar_sentence_filter(inp: str) -> [str]:
    return [
        sent.strip()
        for sent in sent_tokenize(inp.lower())
        if sent.strip() != ""
    ]


def termfreq(inp: [str]) -> {str: float}:
    return {t: (inp.count(t) / len(inp)) for t in set(inp)}


def inv_termfreq(all_words: {str}, bodies: [[str]]) -> {str: float}:
    itf = dict()
    for e, t in enumerate(all_words):
        itf[t] = log(
            (len(bodies) + 1) /
            (len([None for extr in bodies if t in extr]) + 1)
        )
        if e % 50 == 0:
            print("\b" * 100, end="")
            print(
                f"{e} words out of {len(all_words)} done ({100*(e/len(all_words)):0.2f}%)",
                end="",
            )
            stdout.flush()
    print()
    return itf


def tfidf(tf: {str: float}, idf: {str: float}) -> {str: float}:
    return {t: tf[t] * idf[t] for t in tf.keys()}


def similar(url: str) -> [str]:
    if not exists("urls.pkl"):
        print(f'getting initial url "{url}"')
        with urlopen(url) as resp:
            bs = BS(resp.read())
        print(f'filtering initial url "{url}"')
        orig_body = similar_text_filter(bs.get_text())
        with open("orig_body.pkl", "wb") as x:
            dump(orig_body, x)
        print(f'tf for url "{url}"')
        orig_tf = termfreq(orig_body)
        with open("orig_tf.pkl", "wb") as x:
            dump(orig_tf, x)
        urls = [
            link.get("href")
            for link in bs.find_all("a")
            if link.get("href") and link.get("href")[0] != "#"
        ]
        urls = fix_urls(urlparse(url), urls)
        with open("urls.pkl", "wb") as x:
            dump(urls, x)
    else:
        with open("orig_body.pkl", "rb") as x:
            orig_body = load(x)
        with open("orig_tf.pkl", "rb") as x:
            orig_tf = load(x)
        with open("urls.pkl", "rb") as x:
            urls = load(x)

    if not exists("rec_urls.pkl"):
        rec_urls = []
        other_bodies = []
        for i, curl in enumerate(urls):
            # recurse once
            print(f'getting refs "{curl}" ({i+1} / {len(urls)})')
            try:
                with urlopen(curl) as resp:
                    bs = BS(resp.read())
            except Exception as e:
                print(f'skipping "{curl}" as failed to get text: {e}')
                continue
            rec_urls += fix_urls(
                urlparse(curl),
                [
                    link.get("href")
                    for link in bs.find_all("a")
                    if link.get("href") and link.get("href")[0] != "#"
                ],
            )
            # then scrape bodies
            print(f'filtering "{curl}" ({i+1} / {len(urls)})')
            new_body = similar_text_filter(bs.get_text())
            print(f'tf "{curl}" ({i+1} / {len(urls)})')
            other_bodies += [
                copy(
                    (
                        curl,
                        new_body,
                        termfreq(new_body),
                    )
                )
            ]
        with open("rec_urls.pkl", "wb") as r_u, open("other_bodies.pkl", "wb") as o_b:
            dump(rec_urls, r_u)
            dump(other_bodies, o_b)
    else:
        with open("rec_urls.pkl", "rb") as r_u, open("other_bodies.pkl", "rb") as o_b:
            rec_urls = load(r_u)
            other_bodies = load(o_b)

    # scrape the recursive
    if not exists("rec_other_bodies.pkl"):
        rec_other_bodies = []
        # filter out wikipedia links and pdfs
        regex_wiki = re.compile(r".*\.wiki.*\.org")
        rec_urls = [
            curl
            for curl in rec_urls
            if curl
            and not re.fullmatch(regex_wiki, urlparse(curl).netloc)
            and not urlparse(curl).path.endswith("pdf")
        ]
        # lets keep going, up to 1000
        i = 0
        for curl in set(rec_urls).difference(set(urls + [url])):
            print(f'getting refs "{curl}" ({i+1} / 1000)')
            try:
                with urlopen(curl, timeout=10.0) as resp:
                    bs = BS(resp.read())
            except Exception as e:
                print(f'skipping "{curl}" as failed to get text: {e}')
                continue
            print(f'filtering "{curl}" ({i+1} / 1000)')
            new_body = similar_text_filter(bs.get_text())
            print(f'tf "{curl}" ({i+1} / 1000)')
            rec_other_bodies += [
                copy(
                    (
                        curl,
                        new_body,
                        termfreq(new_body),
                    )
                )
            ]
            i += 1
            if i >= 1000:
                break
        with open("rec_other_bodies.pkl", "wb") as r_o_b:
            dump(rec_other_bodies, r_o_b)
    else:
        with open("rec_other_bodies.pkl", "rb") as r_o_b:
            rec_other_bodies = load(r_o_b)

    word_sset = [x[1] for x in other_bodies + rec_other_bodies] + orig_body
    if not exists("all_words.pkl"):
        print("make sets")
        all_words = set()
        for x in word_sset:
            all_words = all_words.union(x)
        with open("all_words.pkl", "wb") as a_w:
            dump(all_words, a_w)
    else:
        with open("all_words.pkl", "rb") as a_w:
            all_words = load(a_w)

    if not exists("idf.pkl"):
        print("make idf")
        idf = inv_termfreq(all_words, word_sset)
        with open("idf.pkl", "wb") as idfpkl:
            dump(idf, idfpkl)
    else:
        with open("idf.pkl", "rb") as idfpkl:
            idf = load(idfpkl)

    print("making tfidf")
    orig_tfidf = tfidf(orig_tf, idf)
    other_bodies = [
        (
            curl,
            body,
            tf,
            tfidf(tf, idf),
        )
        for curl, body, tf in other_bodies + rec_other_bodies
    ]
    orig_highest_sim = set([
        x[0] for x in sorted(orig_tfidf.items(), key=lambda x: x[1], reverse=True)[1:10]
    ])
    highest_sim = []
    for x in other_bodies:
        curr = set([y[0] for y in sorted(
            x[3].items(), key=lambda x:x[1], reverse=True)[:10]])
        if len(orig_highest_sim.intersection(curr)) != 0:
            highest_sim += [(x[0], len(orig_highest_sim.intersection(curr)))]
    return [x[0] for x in sorted(highest_sim, key=lambda x:x[1], reverse=True)][:15]


def scrape_page(url: str, fname: str):
    with urlopen(url) as resp, open(f"{fname}.bdp", 'w') as out:
        bs = BS(resp.read())
        out.write(bs.get_text())


def sent_clean(fname: str):
    with open(f"{fname}.bdp") as inp, open(f"{fname}.sdb", "w") as out:
        for x in similar_sentence_filter(inp.read()):
            out.write(x+" ")


def top_25() -> {str}:
    hold = []
    for fname in glob("*.sdb"):
        with open(fname) as inp:
            body = similar_text_filter(inp.read())
        hold += [(body, termfreq(body),)]
    all_words = set()
    for body, _ in hold:
        all_words = all_words.union(body)
    idf = inv_termfreq(all_words, [x[0] for x in hold])
    tfidfs = [sorted(tfidf(tf, idf).items(), key=lambda x:x[1],
                     reverse=True) for _, tf in hold]
    terms = set()
    slice_size = 0
    while len(terms) < 25:
        slice_size += 1
        coords = [set(copy([y[0] for y in x[:slice_size]])) for x in tfidfs]
        for coord in coords:
            terms = terms.union(coord)
    return terms


def filter_sentences(top_words: {str}) -> {str}:
    kb = []
    for fname in glob("*.sdb"):
        with open(fname) as finp:
            for line in finp:
                if line.strip() == "":
                    continue
                sents = sent_tokenize(line.strip())
                for sent in sents:
                    for top in top_words:
                        if top in word_tokenize(sent):
                            kb += [sent]
    return kb


def main():
    urls = similar(URL)
    for e, x in enumerate(urls):
        scrape_page(x, e)
    for fname in glob("*.bdp"):
        sent_clean(fname.split('.')[0])
    top = top_25()
    if not exists("tterms.pkl"):
        print(f"top terms: {top}")
        tterms = []
        while len(tterms) < 10:
            x = input("Top term inp: ")
            if x in top:
                tterms += [x]
            else:
                print('invalid input')
        with open('tterms.pkl', 'wb') as tt:
            dump(tterms, tt)
    else:
        with open('tterms.pkl', 'rb') as tt:
            tterms = load(tt)
    print(f'chosen terms: {tterms}')
    kb = filter_sentences(tterms)
    print(kb)
    with open("knowledgebase.pkl", 'wb') as kbf:
        dump(kb, kbf)


if __name__ == "__main__":
    main()
